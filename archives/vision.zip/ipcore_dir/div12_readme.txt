The following files were generated for 'div12' in directory
/home/vka/Programming/VHDL/workspace/sysrek/skin_color_segm/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * div12.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * div12.ngc
   * div12.v
   * div12.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * div12.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * div12.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * div12.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * div12_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * div12.gise
   * div12.xise

Deliver Readme:
   Readme file for the IP.

   * div12_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * div12_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

